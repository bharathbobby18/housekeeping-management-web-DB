<!DOCTYPE html>
<html>
<head>
    <title>SIMATS | HMS | Job Status</title>
    <link rel="stylesheet" type="text/css" href="styleemplogin.css">
	<style>
		
			.container {
    background-color:#005690;
}
.logo {
    font-size: 2em;
    color: #fff;
    user-select: none;
}
h1 {
    text-align: center;
    margin-top: 10px;
    font-family:poppins,sans-serif; /* You can adjust this margin to your preference */
}

header h1 {
    display: inline;
    font-family:inter;
    font-weight: 400;
    font-size: 32px;
    float: left;
    margin-top: 0px;
    margin-right: 10px;
}
.homered {
    background-color: #005690;
    padding: 30px 10px 20px 10px;
}

  .divider{
	background-color: rgb(0, 86, 144);
	height: 5px;
  }
  
  .homeblack:hover{
	background-color: rgb(0 86 144);
	padding: 30px 10px 18px 10px;
  
  }


  header {
    background: #005690;
    color: white;
    padding: 18px 20px 53px 40px;
    height: 4px;
}

		.divider {
    background-color: #8BCA02;
    height: 5px;
}
nav ul li a {
    color: #00000;
    text-decoration: none;
}
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
    background-color: #8bca02;
}
.hidden-image {
            display: none;
        }
    </style>
</head>
<body>
	
	<header>
		<nav>
			<h1><h1 class="container">Housekeeping Management</h1>
			<ul id="navli">
				<li><a class="homered" href="index.html"><b>Home</b></a></li>
				<li><a class="homered" href="assign.php"><b>Manager</b></a></li>
                <li><a class="homeblack" href="login.html"><b>Log Out</b></a></li>
			</ul>
		</nav>
	</header>
    <div class="divider"></div>
<body>
            <h1>Job status</h1>
    <table>
        
            <tr>
                <th align = "center">Job ID</th>
                <th align = "center">From Date</th>
                <th align = "center">To Date</th>
                <th align = "center">Floor No</th>
                <th align = "center">Supervisor</th>
                <th align = "center">Status</th>
                <th align="center">Image</th>
            </tr>
      
            <?php
$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "housekeeping";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if (!$conn) {
    echo "Database Connection Failed";
}

// Query to fetch data from the 'job' table with a CASE statement
$sql = "SELECT j.job_id, j.from_date, j.to_date, j.floor_no, u.firstName AS supervisor_name,
    CASE 
        WHEN j.status = 'Completed' THEN 'Completed'
        ELSE 'Pending'
    END AS status,
    j.image
    FROM job j
    LEFT JOIN userinfo u ON j.supervisor = u.bio_id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["job_id"] . "</td>";
        echo "<td>" . $row["from_date"] . "</td>";
        echo "<td>" . $row["to_date"] . "</td>";
        echo "<td>" . $row["floor_no"] . "</td>";
        echo "<td>" . $row["supervisor_name"] . "</td>"; // Display supervisor's firstName
        echo "<td>" . $row["status"] . "</td>";

        // Add a dropdown button for "Completed" status
        if ($row["status"] === 'Completed') {
            echo '<td><button class="toggle-image-button" data-image-src="' . $row["image"] . '">Show Image</button></td>';
        } else {
            echo '<td></td>'; // Empty cell for non-completed rows
        }
        echo "</tr>";
    }
}

$conn->close();
?>

       
    </table>
    <script>
    const toggleImageButtons = document.querySelectorAll(".toggle-image-button");

    toggleImageButtons.forEach(button => {
        button.addEventListener("click", () => {
            const imageSrc = button.getAttribute("data-image-src");

            // Open a new window or tab with the image
            window.open(imageSrc, "_blank");
        });
    });
</script>
</body>
</html>
