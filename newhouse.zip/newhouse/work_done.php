<!DOCTYPE html>
<html>
<head>
    <title>Work Done | Housekeeping Management System</title>
    <meta http-equiv="refresh" content="5;url=sloginwel.php"> <!-- Redirect to sloginwel.php after 5 seconds -->
</head>
<body>
    <div>
        <h1>Work has been done</h1>
        <!-- You can add any additional content or styling here -->
    </div>
</body>
</html>
