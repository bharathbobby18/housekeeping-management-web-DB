<!DOCTYPE html>
<html>

<head>
   

    <!-- Title Page-->
    <title>building|Housekeeping</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
    <style>
        <style>
        header{
        background-color:#005690;
    
    }
    .divider {
    background-color: #8BCA02;
    height: 5px;
}
.homered {
    background-color: #005690;
    padding: 30px 10px 18px 10px;
} header {
    background: #005690;
    color: white;
    padding: 18px 20px 53px 40px;
    height: 4px;
}

       
        header{
        background-color:#005690;
    
    }
    .divider {
    background-color: #8BCA02;
    height: 5px;
}
        </style>
</head>

<body>
    <header>
        <nav>
            <h1>Housekeeping Management</h1>
            <ul id="navli">
                <li><a class="homeblack" href="aloginwel.php">HOME</a></li>
                
                <li><a class="homeblack" href="login.html">Log Out</a></li>
            </ul>
        </nav>
    </header>
    
    <div class="divider"></div>




    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Building Info</h2>
                    <form action="buildingprocess.php" method="POST">
                         <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="building name" name="buildingname" required="required">
                                </div>
                            </div>
                        </div>





                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="building id" name="building_id" required="required">
                        </div>
                       
                        
                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="floor numer" name="floor_no" required="required" >
                        </div>

                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="room number" name= "room_no" required="required">
                        </div>
                        <div class="input-group">
    <select class="input--style-1" type="number" placeholder="room type"name="room_type">
        <option value="class room">classroom</option>
        <option value="restroom">restroom</option>
        <option value="staff room">Staffroom</option>
        <option value="lab">lab</option>

        <!-- Add more room types as needed -->
    </select>
</div>

                        
                        







                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body>

</html>
<!-- end document-->