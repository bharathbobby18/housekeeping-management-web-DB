<?php
require_once('process/dbh.php');

if (isset($_GET['bio_id'])) {
    $bio_id = $_GET['bio_id'];

    // Construct the SQL query to delete the asset
    $deleteSql = "DELETE FROM requestasset WHERE bio_id = '$bio_id'";
    
    // Execute the delete query
    if (mysqli_query($conn, $deleteSql)) {
        // Successful deletion
        header("Location:reqdasset.php"); // Redirect back to the listing page
        exit();
    } else {
        // Error deleting the asset
        echo "Error deleting asset: " . mysqli_error($conn);
    }
} else {
    echo "Invalid ID or ID is missing.";
}
?>
