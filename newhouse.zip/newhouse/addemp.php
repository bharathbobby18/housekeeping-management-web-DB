
<!DOCTYPE html>
<html>

<head>
   

    <!-- Title Page-->
    <title>SIMATS| HMS | Add Employee</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
    <style>
        header{
        background-color:#005690;
    
    }
    .divider {
    background-color: #8BCA02;
    height: 5px;
}
.homered {
    background-color: rgb(0, 43, 198);
    padding: 30px 10px 22px 10px;
}
.logo {
    font-size: 2em;
    color: #fff;
    user-select: none;
}

header h1 {
    display: inline;
    font-family:inter;
    font-weight: 400;
    font-size: 32px;
    float: left;
    margin-top: 0px;
    margin-right: 10px;
}
.homered {
    background-color: #005690;
    padding: 30px 10px 20px 10px;
}

  .divider{
	background-color: rgb(0, 86, 144);
	height: 5px;
  }
  
  .homeblack:hover{
	background-color: rgb(0 86 144);
	padding: 30px 10px 18px 10px;
  
  }


  header {
    background: #005690;
    color: white;
    padding: 18px 20px 53px 40px;
    height: 4px;
}
		.divider {
    background-color: #8BCA02;
    height: 5px;
}
nav ul li a {
    color: #00000;
    text-decoration: none;
}
.input--style-1 {
        width: 100%;
    }

        </style>
        <script>
        function validateEmail() {
            var email = document.forms["registrationForm"]["email"].value;

            // Check if the email contains '@'
            if (!email.includes('@')) {
                alert("Please enter a valid email address.");
                return false;
            }

            return true;
        }

        function validateContactNumber() {
            var contactNumber = document.forms["registrationForm"]["contact"].value;

            // Check if the contact number is exactly 10 digits
            if (contactNumber.length !== 10 || isNaN(contactNumber)) {
                alert("Please enter a valid 10-digit contact number.");
                return false;
            }

            return true;
        }

        function validateBioID() {
            var bioID = document.forms["registrationForm"]["bioid"].value;

            // Check if the bio ID is exactly 9 digits
            if (bioID.length !== 9 || isNaN(bioID)) {
                alert("Please enter a valid 9-digit bio ID.");
                return false;
            }

            return true;
        }

        function validateForm() {
            return validateEmail() && validateContactNumber() && validateBioID();
            // Add more validation functions as needed
        }
    </script>
</head>

<body>
    <header>
        
        <nav>
            <h1>Housekeeping Management</h1>
            <ul id="navli">
                <li><a class="homeblack" href="index.html">Home</a></li>
				<li><a class="homeblack" href="aloginwel.php">Admin</a></li>
				
                <li><a class="homeblack" href="login.html">Log Out</a></li>
            </ul>
        </nav>
    </header>
    
    <div class="divider"></div>




    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Registration Info</h2>

                    <form action="addempprocess.php" method="POST" >
                         <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="FirstName" name="firstName" required="required">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-1" type="text" placeholder="LastName" name="lastName" required="required">
                                </div>
                            </div>
                        </div>



 

                        <div class="input-group">
                            <input class="input--style-1" type="email" placeholder="Email" name="email" required="required">
                        </div>
                        <div class="input-group">
    <p>Date of Birth</p>
    <input class="input--style-1" type="date" placeholder="Date of Birth" name="birthday" required="required">
</div>

                        
                        <div class="input-group">
                        <input class="input--style-1" type="tel" placeholder="Mobile Number (10 digits)" name="contact" pattern="\d{10}" required="required">


                        </div>

                        <div class="input-group">
    <input class="input--style-1" type="text" placeholder="Bio Id (9 digits)" name="bioid" pattern="\d{9}" title="Bio ID must be 9 digits" required="required">
</div>

                        
                         <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Password" name="password" required="required">
                        </div>

                        <div class="input-group">
    <select class="input--style-1" name="designation" id="Designation" required="required" onchange="toggleSupervisor()">
        <option value="" disabled selected>Select Designation</option>
        <option value="Worker">Worker</option>
        <option value="Supervisor">Supervisor</option>
        <option value="Manager">Manager</option>
    </select>
</div>

<div class="input-group" id="supervisorGroup" style="display: none;">
    <select class="input--style-1" name="supervisor" id="supervisor">
        <option value="" disabled selected>Select Supervisor</option>
        <!-- Add options for supervisors here -->
    </select>
</div>

                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Qualification" name="qualification" required="required">
                        </div>







                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<script>
    // Function to fetch and populate supervisors
    function populateSupervisors() {
        console.log("Fetching supervisors...");
        var supervisorSelect = document.getElementById("supervisor");

        // Clear existing options
        supervisorSelect.innerHTML = '<option value="" disabled selected>Select Supervisor</option>';

        // Fetch supervisors from the server using AJAX
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            console.log("XHR State:", xhr.readyState, "Status:", xhr.status);

            if (xhr.readyState == 4) {
                console.log("Response:", xhr.responseText);

                if (xhr.status == 200) {
                    try {
                        var supervisors = JSON.parse(xhr.responseText);
                        console.log("Supervisors:", supervisors); // Check if this prints the expected data

                        // Populate options with supervisor names
                        supervisors.forEach(function (supervisor) {
                            var option = document.createElement("option");
                            option.value = supervisor.bio_id; // Use the correct property for the supervisor ID
                            option.text = supervisor.firstName; // Use the correct property for the supervisor's first name
                            supervisorSelect.appendChild(option);
                        });
                    } catch (error) {
                        console.error("Error parsing JSON:", error);
                    }
                } else {
                    console.error("Request failed with status:", xhr.status);
                }
            }
        };

        xhr.open("GET", "get_supervisors.php", true);
        xhr.send();
    }

    // Call populateSupervisors initially to set the initial state
    populateSupervisors();

    function toggleSupervisor() {
        var designationSelect = document.getElementById("designation");
        var supervisorGroup = document.getElementById("supervisorGroup");

        // If Worker is selected, show the supervisor selection, else hide it
        supervisorGroup.style.display = (designationSelect.value === "Worker") ? "block" : "none";
    }

    function submitForm() {
        // Your existing submitForm function
    }
</script>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body>

</html>
<!-- end document-->