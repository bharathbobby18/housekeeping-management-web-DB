<?php
session_start();
require_once('process/dbh.php');
$supervisorBioId = $_SESSION["bio_id"];

// SQL query to select jobs assigned to the logged-in supervisor with supervisor's firstName
$sql = "SELECT job.job_id, job.floor_no, userinfo.firstName
        FROM job
        JOIN userinfo ON job.supervisor = userinfo.bio_id
        WHERE job.supervisor = '$supervisorBioId' AND job.status != 'completed'";

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Error: " . mysqli_error($conn));
}

// Check if a job has been marked as "completed" and delete it from the database
if (isset($_GET['completed_job_id'])) {
    $completedJobId = $_GET['completed_job_id'];
    $deleteSql = "DELETE FROM job WHERE job_id = '$completedJobId' AND supervisor = '$supervisorBioId'";
    $deleteResult = mysqli_query($conn, $deleteSql);

    if ($deleteResult) {
        // Job successfully deleted
        echo "<script>alert('Job marked as completed and deleted.');</script>";
    } else {
        // Error occurred while deleting the job
        echo "<script>alert('Error deleting the job.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel | Housekeeping Management System</title>
    <link rel="stylesheet" type="text/css" href="styleemplogin.css">
    <style>
        		.container {
    background-color:#005690;
}
.logo {
    font-size: 2em;
    color: #fff;
    user-select: none;
}

header h1 {
    display: inline;
    font-family:inter;
    font-weight: 400;
    font-size: 32px;
    float: left;
    margin-top: 0px;
    margin-right: 10px;
}
.homered {
    background-color: #005690;
    padding: 30px 10px 20px 10px;
}

  .divider{
	background-color: rgb(0, 86, 144);
	height: 5px;
  }
  
  .homeblack:hover{
	background-color: rgb(0 86 144);
	padding: 30px 10px 18px 10px;
  
  }
    .homeblack:{
	color:#fffff;
  
  }


  header {
    background: #005690;
    color: white;
    padding: 18px 20px 53px 40px;
    height: 4px;
}

		.divider {
    background-color: #8BCA02;
    height: 5px;
}
nav ul li a {
    color: #fffff;
	font-size:18px;
	
    text-decoration: none;
}
        
            .container {
    background-color:#005690;
}




        header {
    background: #005690;
    color: white;
    padding: 8px 20px 6px 40px;
    height: 50px;
}
        .divider {
    background-color: #8BCA02;
    height: 5px;
}

.accept-button {
    background-color: #8BCA02; /* Green color for the button */
    color: white;
    padding: 5px 25px;
	
    text-decoration: none;
    border-radius: 5px;
}

.accept-button:hover {
    background-color: #5F9900; /* Darker green color on hover */
}
.details-button {
        background-color: #0074D9; /* Blue color for the button */
        color: white;
        padding: 5px 15px;
        text-decoration: none;
        border-radius: 5px;
    }

    .details-button:hover {
        background-color: #0056b3; /* Darker blue color on hover */
    }
    th {
    background-color:#8bca02;
    color: white;
}

    </style>
</head>
<body>
    <header>
        <nav>
            <h1 class="container">Housekeeping Management</h1>
            <ul id="navli">
				<li><a  href="index.html">Home</a></li>
                <li><a  href="assetreq.php">Request Assets</a></li>
                <li><a  href="login.html">Logout</a></li>
            </ul>
        </nav>
    </header>
    <div class="divider"></div>

<table>
    <tr>
        <th>Job ID</th>
        <th>Floor Number</th>
        <th>Supervisor's Name</th>
        <th>Action</th>
    </tr>

    <?php
    while ($job = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $job['job_id'] . "</td>";
        echo "<td>" . $job['floor_no'] . "</td>";
        echo "<td>" . $job['firstName'] . "</td>";
        echo "<td>";
        echo "<a href='room_list.php?job_id=" . $job['job_id'] . "&floor_no=" . $job['floor_no'] . "' class='accept-button'>Accept</a>";
		echo "&nbsp;&nbsp;";
        echo "<a href='job_details.php?job_id=" . $job['job_id'] . "' class='details-button'>Details</a>";
        echo "</td>";
        echo "</tr>";
    }
    ?>

</table>
</body>
</html>
