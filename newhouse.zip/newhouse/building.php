<!DOCTYPE html>
<html>

<head>
   

    <!-- Title Page-->
    <title>building|Housekeeping</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
    <style>
        
		header h1 {
			display: inline;
			font-family: inter;
			font-weight: 400;
			font-size: 32px;
			float: left;
			margin-top: 0px;
			margin-right: 10px;
		}


		header {
			background: #005690;
			color: white;
			padding: 8px 20px 6px 40px;
			height: 50px;
		}
		.divider {
			background-color: #8BCA02;
			height: 5px;
		} 

		.homered {
			background-color: #005690;
			padding: 30px 10px 18px 10px;

			   
			 
		}
        .input--style-1 {
        width: 100%;
    }
        </style>
</head>

<body>
    <header>
        <nav>
            <h1>Housekeeping Management</h1>
            <ul id="navli">
            <li><a class="homeblack" href="index.html">Home</a></li>
				
				<li><a class="homeblack" href="aloginwel.php">Admin</a></li>
                
                <li><a class="homeblack" href="login.html">Log Out</a></li>
            </ul>
        </nav>
    </header>
    
    <div class="divider"></div>




    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Building Info</h2>
                    <form action="buildingprocess.php" method="POST">
                         <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="Building name" name="buildingname" required="required">
                                </div>
                            </div>
                        </div>





                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="Building id" name="building_id" required="required">
                        </div>
                       
                        
                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="Floor numer" name="floor_no" required="required" >
                        </div>

                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="Room number" name= "room_no" required="required">
                        </div>
                        <div class="input-group">
    <select class="input--style-1" type="number" placeholder="Room type"name="room_type">
        <option value="class room">classroom</option>
        <option value="restroom">restroom</option>
        <option value="staff room">Staffroom</option>
        <option value="lab">lab</option>

        <!-- Add more room types as needed -->
    </select>
</div>

                        
                        







                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body>

</html>
<!-- end document-->