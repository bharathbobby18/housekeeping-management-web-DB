<?php
session_start();
?>
<?php
require_once('dbh.php'); // Include your database connection file.

// Initialize variables for success message and error message
$successMessage = "";
$errorMessage = "";

// Check if the form fields are set before accessing them
if (isset($_POST['from'], $_POST['to'], $_POST['floor_no'], $_POST['supervisor'])) {
    // Retrieve job details from the form
    $from = $_POST['from'];
    $to = $_POST['to'];
    $floor_no = $_POST['floor_no'];
    $supervisor = $_POST['supervisor'];

    // Do not provide a value for the primary key column (e.g., 'id') in the INSERT statement.
    // Let the database automatically generate the primary key value.
    $insertJobSql = "INSERT INTO job (from_date, to_date, floor_no, supervisor) 
                     VALUES ('$from', '$to', '$floor_no', '$supervisor')";

    if (mysqli_query($conn, $insertJobSql)) {
        // Get the auto-generated job ID
        $job_id = mysqli_insert_id($conn);

        // Set the success message
        //$successMessage = "The job has been assigned successfully.";
		// Redirect browser
		header("Location: ../managerwel.php");
 
		exit;
    } else {
        // Handle the case where the insert query fails
        $errorMessage = "Error: " . mysqli_error($conn);
    }
} else {
    // Handle the case where some form fields are not set
    $errorMessage = "Form fields are missing.";
}

mysqli_close($conn);
?>

